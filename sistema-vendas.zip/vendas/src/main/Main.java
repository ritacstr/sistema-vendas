package main;

import model.Venda;

public class Main {
	public static void main(String[] args) {
	
		Venda venda1 = new Venda();
		
		venda1.calcularTotal();
		venda1.setRegrasDePagamento();
	}
}
