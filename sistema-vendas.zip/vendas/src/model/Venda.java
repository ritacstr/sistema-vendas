package model;

import java.util.Scanner;

public class Venda {
	private double totalVendido;
	private RegraDePagamento pagamento;
	
	public Venda() {};
	
	Scanner entry = new Scanner(System.in);

	public double getTotalVendido() {
		return totalVendido;
	}

	public void setTotalVendido(double totalVendido) {
		this.totalVendido = totalVendido;
	}

	public RegraDePagamento getPagamento() {
		return pagamento;
	}

	public void setPagamento(RegraDePagamento pagamento) {
		this.pagamento = pagamento;
	};
	
	public void setRegrasDePagamento() {
		System.out.println("Informe a forma de pagamento: \n 1. Pagamento a vista, 2. Pagamento a prazo");
		int formaPagamento = entry.nextInt();
		
		if(formaPagamento < 0) {
			System.out.println("Forma de pagamento inv�lida");
			return;
		} else if(this.getTotalVendido() < 100.0) {
			System.out.println("S� � poss�vel selecionar pagamento a prazo caso o valor da compra seja superior a R$ 100,00");
		} else {
			switch(formaPagamento) {
			case 1:
				pagamento = new PagamentoAVista();
				this.setPagamento(pagamento);
				pagamento.pagar(this);
				break;
			case 2:
				pagamento = new PagamentoAPrazo();
				this.setPagamento(pagamento);
				pagamento.pagar(this);
			}
		}
	};
	
	public void calcularTotal() {
		System.out.println("Digite o valor da venda: ");
		double total = entry.nextDouble();
		this.setTotalVendido(total);
	}
}
