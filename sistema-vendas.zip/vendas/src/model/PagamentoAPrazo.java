package model;

import java.util.Scanner;

public class PagamentoAPrazo implements RegraDePagamento{
	
	Scanner entry = new Scanner(System.in);

	@Override
	public double pagar(Venda venda) {
		System.out.println("Total: R$" + venda.getTotalVendido());
		System.out.println("Em quantas vezes deseja parcelar? \nAcima de 6 parcelas ser� acrescido 15% de juros");
		int parcelas = entry.nextInt();
		
		if(parcelas < 6) {
			double parcela = venda.getTotalVendido() / parcelas;
			double total = parcela * parcelas;
			
			System.out.println("Em " + parcelas + " de R$" + parcela + " o valor final ser� de R$" + total);
		}
		
		return parcelas;
	}

}
