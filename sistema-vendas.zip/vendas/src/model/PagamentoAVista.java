package model;

import java.util.Scanner;

public class PagamentoAVista implements RegraDePagamento{
	
	Scanner entry = new Scanner(System.in);

	@Override
	public double pagar(Venda venda) {
		System.out.println("Total R$" + venda.getTotalVendido());
		System.out.println("Informe o valor recebido: ");
		double valorRecebido = entry.nextFloat();
		
		double troco = venda.getTotalVendido() - valorRecebido;
		troco = Math.abs(troco);
		System.out.println("O troco � de R$" + troco);
		return troco;
	}

}
