package model;

public interface RegraDePagamento {
	public double pagar(Venda venda);
}
